<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Student ID Display';
$string['studentinfo'] = 'Student: {name} (ID: {id})';
$string['noidnumber'] = 'Not set';