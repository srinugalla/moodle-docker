<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version = 2025061301; // Updated version
$plugin->requires = 2024100700; // Moodle 5.0 minimum
$plugin->component = 'local_studentid_display';
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.1';